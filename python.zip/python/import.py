import module

print(module.foo)
module.hello()

print(module.__name__)
