import json
sensor_data={'temperature':26,'humidity':34}

result=json.dumps(sensor_data)
print(result)
print(type(result))
print(json.dumps(result,indent=4,sort_keys=True))
#result1=json.loads(result)
#print(result1)
