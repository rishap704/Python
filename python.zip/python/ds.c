dict={'name':"xyz",'marks':89}
print(dict[marks])
