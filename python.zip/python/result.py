import sum

input1=int(input("enter a num"))
input2=int(input("enter another number"))

sum.add(input1,input2)
