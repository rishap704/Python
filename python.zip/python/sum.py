def add(self,num1,num2):
    num1=num1+num2
    print("sum is %d",num1)
