i=1
while i<=10:
    print(i,end=" ")
    if i==5:
        break
    i=i+1
print("\n Done")

