class employee:

    name=""
    id1=0
    sal=0.0
    def __init__(self,name,id1,sal):
        self.name=name
        self.id1=id1
        self.sal=sal
    def totalsal(self,bonus):
        total=self.sal+bonus
        print("total salary:",total)
    def prin(self):
        print("Name=",self.name)
        print("Id=",self.id1)
        print("Salary:",self.sal)

emp=employee("fdgd",6,678.0)
#emp.name=input("enter name")
#emp.id1=int(input("enter id"))
#emp.sal=float(input("enter salary"))
emp.prin()
emp.totalsal(5000)

