x=30
y=20
dict ={'temp':x,'humidity':y}
print(dict)
dict['temp']=x
x=90
y=67
print(dict)
tup=("abc",1,2)
print (tup)
tup1=(1,)
print(tup1)
for x in tup:
    print (x)
for x in tup1:
    print(x)
tup2=(2,5)
tup3=tup1+tup2
print(tup3)

for x in tup3:
    print(x)


def addfun(x,y):
    total=x*y
    print("adition is:",total)
addfun(10,30)

m,n=input("enter two num").split()
#print(x,y)
