#!/usr/bin/python3
print("hello world")
name=input("what is your name\n")
print("my name is %s"%(name))
x=int(input("enter a num\n"))
y=int(input("enter another num\n"))


if x>y:
    print("%d is greater"%(x))
else:
    print("%d is greater"%(y))
    
        
