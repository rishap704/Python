foo=100

def hello():
    print("i am from my module.py file")

if __name__ == "__main__":
    print("executing as main program")
    print("value of __name__ id:",__name__)
    hello()
