
import json
sensor_data='{"device-name":"ESP32","Sensor-Details":"DHT11","temperature":20,"humidity":65}'

sensor_result=json.loads(sensor_data)
print(sensor_result)
print(sensor_result['device-name'])
