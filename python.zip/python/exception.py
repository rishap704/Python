numerator=int(input("enter numerator"))
denominator=int(input("enter denominator"))

try:
    quotient=numerator/denominator
    print("Quotient resulr:",quotient)
except ZeroDivisionError:
    print("Denominator can not be zero")
